SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS m_sales_case_status (
  id            INT UNSIGNED     NOT NULL AUTO_INCREMENT COMMENT 'ID',
  code          VARCHAR(20)      NOT NULL                COMMENT 'システムコード（t_sales_case.status に格納する値）',
  display_name  VARCHAR(50)      NOT NULL                COMMENT '表示名（画面でのラベル）',
  display_order TINYINT UNSIGNED NOT NULL DEFAULT 0      COMMENT '表示順',
  is_active     TINYINT(1)       NOT NULL DEFAULT 1      COMMENT '有効フラグ(1=有効/0=無効)',
  created_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日時',
  updated_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日時',

  PRIMARY KEY (id),
  UNIQUE KEY uq_sales_case_status_code (code)

) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='見込案件ステータスマスタ（コードはシステム固定、ラベル/表示順/有効無効のみ編集可能）';

-- シードデータは config/dml/master/tenant/ に分離（DDL はスキーマ定義のみ）
