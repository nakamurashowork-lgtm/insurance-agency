SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS m_activity_type (
  code          VARCHAR(30)      NOT NULL COMMENT '活動種別コード(t_activity.activity_type に格納する値)',
  label         VARCHAR(50)      NOT NULL COMMENT '表示名',
  display_order TINYINT UNSIGNED NOT NULL DEFAULT 0      COMMENT '表示順',
  is_active     TINYINT(1)       NOT NULL DEFAULT 1      COMMENT '有効フラグ(1=有効/0=無効)',
  created_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '作成日時',
  updated_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新日時',

  PRIMARY KEY (code)

) ENGINE=InnoDB
  DEFAULT CHARSET=utf8mb4
  COLLATE=utf8mb4_unicode_ci
  COMMENT='活動種別マスタ';

-- シードデータは config/dml/master/tenant/ に分離（DDL はスキーマ定義のみ）
