-- =====================================================================
-- マスターデータ: m_activity_purpose_type（活動用件区分マスタ）
-- 投入先: 検証環境・本番環境 両方
-- 用途  : t_activity.purpose_type に格納されるコード集合
--        （Excel日報の実態から導出）
-- 件数  : 9件
-- 依存  : なし
-- 関連DDL: config/ddl/tenant/m_activity_purpose_type.sql
-- =====================================================================

SET NAMES utf8mb4;

INSERT INTO m_activity_purpose_type (code, label, display_order, is_active) VALUES
  ('renewal',      '満期対応',           1,  1),
  ('new_business', '新規開拓',           2,  1),
  ('cross_sell',   'クロスセル提案',     3,  1),
  ('accident',     '事故対応',           4,  1),
  ('follow_up',    'フォロー',           5,  1),
  ('admin',        '内務・社内作業',     6,  1),
  ('meeting',      '会議・ミーティング', 7,  1),
  ('training',     '研修・勉強会',       8,  1),
  ('other',        'その他',             99, 1)
ON DUPLICATE KEY UPDATE
  label         = VALUES(label),
  display_order = VALUES(display_order);
