-- =====================================================================
-- マスターデータ: m_activity_type（活動種別マスタ）
-- 投入先: 検証環境・本番環境 両方
-- 用途  : t_activity.activity_type に格納されるコード集合
--        （旧 ActivityController::ALLOWED_ACTIVITY_TYPES から移行）
-- 件数  : 5件
-- 依存  : なし
-- 関連DDL: config/ddl/tenant/m_activity_type.sql
-- =====================================================================

SET NAMES utf8mb4;

INSERT INTO m_activity_type (code, label, display_order, is_active) VALUES
  ('visit',  '訪問',       1,  1),
  ('call',   '電話',       2,  1),
  ('email',  'メール',     3,  1),
  ('online', 'オンライン', 4,  1),
  ('other',  'その他',     99, 1)
ON DUPLICATE KEY UPDATE
  label         = VALUES(label),
  display_order = VALUES(display_order);
