-- =====================================================================
-- マスターデータ: m_renewal_method（更改方法マスタ）
-- 投入先: 検証環境・本番環境 両方
-- 用途  : t_renewal_case.renewal_method に格納されるラベル集合
--        （旧 RenewalCaseDetailView のハードコード値から移行）
-- 件数  : 3件
-- 依存  : なし
-- 関連DDL: config/ddl/tenant/m_renewal_method.sql
-- 備考  : UNIQUE キーは label。label 変更時は display_order/is_active のみ更新。
-- =====================================================================

SET NAMES utf8mb4;

INSERT INTO m_renewal_method (label, display_order, is_active) VALUES
  ('対面',     1, 1),
  ('郵送',     2, 1),
  ('電話募集', 3, 1)
ON DUPLICATE KEY UPDATE
  display_order = VALUES(display_order),
  is_active     = VALUES(is_active);
