-- =====================================================================
-- マスターデータ: m_sales_case_status（見込案件ステータスマスタ）
-- 投入先: 検証環境・本番環境 両方
-- 用途  : t_sales_case.status に格納されるコード集合
--        （code はアプリロジックに依存するため変更不可。
--         ラベル・表示順・有効無効のみ編集可能。）
-- 件数  : 5件
-- 依存  : なし
-- 関連DDL: config/ddl/tenant/m_sales_case_status.sql
-- =====================================================================

SET NAMES utf8mb4;

INSERT INTO m_sales_case_status (code, display_name, display_order, is_active) VALUES
  ('open',        '商談中', 1, 1),
  ('negotiating', '交渉中', 2, 1),
  ('won',         '成約',   3, 1),
  ('lost',        '失注',   4, 1),
  ('on_hold',     '保留',   5, 1)
ON DUPLICATE KEY UPDATE
  display_name  = VALUES(display_name),
  display_order = VALUES(display_order);
