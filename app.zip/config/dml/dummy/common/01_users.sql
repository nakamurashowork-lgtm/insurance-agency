-- =====================================================================
-- ダミーデータ: users
-- 投入先: 検証環境のみ（本番禁止）
-- 用途  : 動作確認用のテストユーザー
-- 件数  : 3件（管理者／一般／ローカル開発）
-- ID範囲: 1, 2, 99
-- 依存  : なし（最初に投入する）
-- 関連DDL: config/ddl/common/users.sql
-- =====================================================================

SET NAMES utf8mb4;

-- ユーザーID=1: テスト管理者（システム管理者権限あり）
INSERT IGNORE INTO users (
  id, google_sub, email, name, display_name,
  is_system_admin, status, is_deleted,
  totp_secret, totp_enabled, totp_verified_at,
  created_by, updated_by
) VALUES (
  1, 'test-admin-google-sub-000001', 'test-admin@insurance-test.example.jp', 'テスト管理者', 'テスト管理者',
  1, 1, 0,
  NULL, 0, NULL,
  NULL, NULL
);

-- ユーザーID=2: テスト一般ユーザー（担当者として使用）
INSERT IGNORE INTO users (
  id, google_sub, email, name, display_name,
  is_system_admin, status, is_deleted,
  totp_secret, totp_enabled, totp_verified_at,
  created_by, updated_by
) VALUES (
  2, 'test-user-google-sub-000002', 'test-user@insurance-test.example.jp', 'テストユーザー', 'テスト担当者',
  0, 1, 0,
  NULL, 0, NULL,
  1, 1
);

-- ユーザーID=99: ローカル開発用（APP_ENV=local 専用、本番DB投入禁止）
INSERT IGNORE INTO users (
  id, google_sub, email, name, display_name,
  is_system_admin, status, is_deleted,
  totp_secret, totp_enabled, totp_verified_at,
  created_by, updated_by
) VALUES (
  99, NULL, 'dev@local.test', 'Dev User', 'Dev User',
  0, 1, 0,
  NULL, 0, NULL,
  1, 1
);
