-- =====================================================================
-- ダミーデータ: t_sales_case（見込案件）
-- 投入先: 検証環境のみ（本番禁止）
-- 用途  : 動作確認用の見込案件サンプル（商談中/交渉中/成約/失注）
-- 件数  : 4件
-- ID範囲: 9001 - 9004
-- 依存  : 02_m_customer.sql, 01_m_staff.sql, m_sales_case_status（DDLシード）
-- 関連DDL: config/ddl/tenant/t_sales_case.sql
-- =====================================================================

SET NAMES utf8mb4;

-- 9001: 商談中（open）・prospect 顧客1005
INSERT INTO t_sales_case (
  id, customer_id, prospect_name, contract_id, case_name, case_type, product_type,
  status, prospect_rank, expected_premium, expected_contract_month, next_action_date,
  memo, assigned_staff_id, staff_id, is_deleted, created_by, updated_by
) VALUES (
  9001, 1005, NULL, NULL, '鈴木様 自動車新規見積', 'other', 'おとなの自動車',
  'open', 'B', 70000, '2026-06', '2026-04-22',
  '紹介案件。他社からの乗換検討中。', 2, 2, 0, 1, 1
);

-- 9002: 交渉中（negotiating）・法人1002 追加契約
INSERT INTO t_sales_case (
  id, customer_id, prospect_name, contract_id, case_name, case_type, product_type,
  status, prospect_rank, expected_premium, expected_contract_month, next_action_date,
  memo, assigned_staff_id, staff_id, is_deleted, created_by, updated_by
) VALUES (
  9002, 1002, NULL, NULL, 'テスト運輸様 事業用動産総合 追加提案', 'other', '動産総合',
  'negotiating', 'A', 350000, '2026-07', '2026-04-25',
  '車両搭載機器の動産総合保険を追加提案中。', 1, 1, 0, 1, 1
);

-- 9003: 成約（won）
INSERT INTO t_sales_case (
  id, customer_id, prospect_name, contract_id, case_name, case_type, product_type,
  status, prospect_rank, expected_premium, expected_contract_month, next_action_date,
  memo, assigned_staff_id, staff_id, is_deleted, created_by, updated_by
) VALUES (
  9003, 1003, NULL, 2008, '山田様 傷害新規', 'other', '普通傷害',
  'won', 'A', 18000, '2025-08', NULL,
  '契約 2008 として成約済み。', 2, 2, 0, 1, 1
);

-- 9004: 失注（lost）・顧客未登録、prospect_name のみ
INSERT INTO t_sales_case (
  id, customer_id, prospect_name, contract_id, case_name, case_type, product_type,
  status, prospect_rank, expected_premium, expected_contract_month, next_action_date,
  lost_reason, memo, assigned_staff_id, staff_id, is_deleted, created_by, updated_by
) VALUES (
  9004, NULL, '田中商店', NULL, '田中商店 火災見積', 'other', 'すまいの保険',
  'lost', 'C', 48000, '2026-03', NULL,
  '他社の既契約継続で見送り。', NULL, 1, 1, 0, 1, 1
);
