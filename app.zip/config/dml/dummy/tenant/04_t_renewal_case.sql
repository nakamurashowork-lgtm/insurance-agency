-- =====================================================================
-- ダミーデータ: t_renewal_case（満期案件）
-- 投入先: 検証環境のみ（本番禁止）
-- 用途  : 動作確認用の満期案件サンプル（各ステータスをカバー）
-- 件数  : 8件
-- ID範囲: 3001 - 3008
-- 依存  : 03_t_contract.sql
-- 関連DDL: config/ddl/tenant/t_renewal_case.sql
-- =====================================================================

SET NAMES utf8mb4;

-- 3001: 未対応（30日以内）・契約2001（法人自動車）
INSERT INTO t_renewal_case (
  id, contract_id, maturity_date, early_renewal_deadline, case_status,
  last_contact_at, next_action_date, renewal_result, expected_premium_amount,
  assigned_staff_id, office_staff_id, remark, renewal_method, procedure_method,
  is_deleted, created_by, updated_by
) VALUES (
  3001, 2001, '2026-05-01', '2026-04-20', 'not_started',
  NULL, '2026-04-20', NULL, 280000,
  1, 2, NULL, '対面', '対面',
  0, 1, 1
);

-- 3002: SJ依頼中・契約2002（法人火災）
INSERT INTO t_renewal_case (
  id, contract_id, maturity_date, early_renewal_deadline, case_status,
  last_contact_at, next_action_date, renewal_result, expected_premium_amount,
  assigned_staff_id, office_staff_id, remark, renewal_method, procedure_method,
  is_deleted, created_by, updated_by
) VALUES (
  3002, 2002, '2026-10-01', '2026-09-15', 'sj_requested',
  '2026-04-10 10:00:00', '2026-04-25', NULL, 55000,
  1, 2, 'SJ に見積依頼済み。', '対面', '対面',
  0, 1, 1
);

-- 3003: 書類作成済・契約2003（法人運輸フリート）
INSERT INTO t_renewal_case (
  id, contract_id, maturity_date, early_renewal_deadline, case_status,
  last_contact_at, next_action_date, renewal_result, expected_premium_amount,
  assigned_staff_id, office_staff_id, remark, renewal_method, procedure_method,
  is_deleted, created_by, updated_by
) VALUES (
  3003, 2003, '2026-07-01', '2026-06-15', 'doc_prepared',
  '2026-04-12 14:00:00', '2026-04-22', NULL, 1200000,
  1, 2, NULL, '対面', '対面',
  0, 1, 1
);

-- 3004: 見積送付済・契約2004（個人自動車）
INSERT INTO t_renewal_case (
  id, contract_id, maturity_date, early_renewal_deadline, case_status,
  last_contact_at, next_action_date, renewal_result, expected_premium_amount,
  assigned_staff_id, office_staff_id, remark, renewal_method, procedure_method,
  is_deleted, created_by, updated_by
) VALUES (
  3004, 2004, '2026-06-01', '2026-05-15', 'quote_sent',
  '2026-04-14 11:00:00', '2026-04-28', NULL, 75000,
  2, 2, '見積送付済み、顧客返答待ち。', '郵送', '署名・捺印',
  0, 1, 1
);

-- 3005: 返送待ち・契約2005（個人火災）
INSERT INTO t_renewal_case (
  id, contract_id, maturity_date, early_renewal_deadline, case_status,
  last_contact_at, next_action_date, renewal_result, expected_premium_amount,
  assigned_staff_id, office_staff_id, remark, renewal_method, procedure_method,
  is_deleted, created_by, updated_by
) VALUES (
  3005, 2005, '2026-09-01', '2026-08-15', 'waiting_return',
  '2026-04-08 15:30:00', '2026-04-24', NULL, 42000,
  2, 2, NULL, '郵送', '署名・捺印',
  0, 1, 1
);

-- 3006: 入金待ち・契約2006（個人自動車）
INSERT INTO t_renewal_case (
  id, contract_id, maturity_date, early_renewal_deadline, case_status,
  last_contact_at, next_action_date, renewal_result, expected_premium_amount,
  assigned_staff_id, office_staff_id, remark, renewal_method, procedure_method,
  is_deleted, created_by, updated_by
) VALUES (
  3006, 2006, '2026-04-01', NULL, 'waiting_payment',
  '2026-04-15 09:00:00', '2026-04-21', NULL, 92000,
  2, 2, NULL, '対面', '対面',
  0, 1, 1
);

-- 3007: 完了・更改済み・契約2008（個人傷害）
INSERT INTO t_renewal_case (
  id, contract_id, maturity_date, early_renewal_deadline, case_status,
  last_contact_at, next_action_date, renewal_result, actual_premium_amount,
  assigned_staff_id, office_staff_id, remark, renewal_method, procedure_method,
  completed_date, is_deleted, created_by, updated_by
) VALUES (
  3007, 2008, '2025-08-01', NULL, 'completed',
  '2025-07-15 10:00:00', NULL, 'renewed', 18000,
  2, 2, NULL, '対面', '対面',
  '2025-07-28', 0, 1, 1
);

-- 3008: 完了・失注・契約2007（法人自動車、廃業）
INSERT INTO t_renewal_case (
  id, contract_id, maturity_date, early_renewal_deadline, case_status,
  last_contact_at, next_action_date, renewal_result, lost_reason, expected_premium_amount,
  assigned_staff_id, office_staff_id, remark, renewal_method, procedure_method,
  completed_date, is_deleted, created_by, updated_by
) VALUES (
  3008, 2007, '2025-04-01', NULL, 'completed',
  '2025-03-10 14:00:00', NULL, 'lost', '顧客廃業により更改不可。', 180000,
  1, 2, NULL, '対面', '対面',
  '2025-03-20', 0, 1, 1
);
