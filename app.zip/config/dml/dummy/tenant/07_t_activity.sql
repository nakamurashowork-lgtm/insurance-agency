-- =====================================================================
-- ダミーデータ: t_activity（活動履歴）
-- 投入先: 検証環境のみ（本番禁止）
-- 用途  : 動作確認用の活動履歴サンプル
--         （活動種別：訪問/電話/メール × 用件：満期/新規/事故/フォロー）
-- 件数  : 8件
-- ID範囲: 8001 - 8008
-- 依存  : 02_m_customer.sql, 03_t_contract.sql, 04_t_renewal_case.sql,
--        05_t_accident_case.sql, 06_t_sales_case.sql, 01_m_staff.sql
-- 関連DDL: config/ddl/tenant/t_activity.sql
-- =====================================================================

SET NAMES utf8mb4;

-- 8001: 訪問・満期対応・顧客1001 契約2001 満期3001
INSERT INTO t_activity (
  id, customer_id, contract_id, renewal_case_id, sales_case_id, accident_case_id,
  activity_date, start_time, end_time, activity_type, purpose_type,
  visit_place, interviewee_name, subject, content_summary, detail_text,
  next_action_date, next_action_note, result_type, staff_id,
  is_deleted, created_by, updated_by
) VALUES (
  8001, 1001, 2001, 3001, NULL, NULL,
  '2026-04-10', '10:00:00', '11:00:00', 'visit', 'renewal',
  'テストコーポレーション本社', '総務部 田中様', '満期更改ヒアリング',
  'フリート契約の更改条件ヒアリング。次回見積提示。',
  NULL, '2026-04-20', '見積書持参', 'success', 1,
  0, 1, 1
);

-- 8002: 電話・満期対応・顧客1001 契約2002 満期3002
INSERT INTO t_activity (
  id, customer_id, contract_id, renewal_case_id, sales_case_id, accident_case_id,
  activity_date, start_time, end_time, activity_type, purpose_type,
  visit_place, interviewee_name, subject, content_summary, detail_text,
  next_action_date, next_action_note, result_type, staff_id,
  is_deleted, created_by, updated_by
) VALUES (
  8002, 1001, 2002, 3002, NULL, NULL,
  '2026-04-10', '14:00:00', '14:30:00', 'call', 'renewal',
  NULL, '総務部 田中様', 'SJ依頼状況連絡',
  '火災保険 SJ 依頼済み、見積到着次第連絡する旨を伝達。',
  NULL, '2026-04-25', NULL, 'success', 1,
  0, 1, 1
);

-- 8003: 訪問・新規開拓・顧客1005 見込9001
INSERT INTO t_activity (
  id, customer_id, contract_id, renewal_case_id, sales_case_id, accident_case_id,
  activity_date, start_time, end_time, activity_type, purpose_type,
  visit_place, interviewee_name, subject, content_summary, detail_text,
  next_action_date, next_action_note, result_type, staff_id,
  is_deleted, created_by, updated_by
) VALUES (
  8003, 1005, NULL, NULL, 9001, NULL,
  '2026-04-12', '15:00:00', '16:00:00', 'visit', 'new_business',
  '鈴木様ご自宅', '鈴木 一郎 様', '自動車保険 新規ヒアリング',
  '他社乗換検討。見積条件を確認。',
  'SV-2026-0412.pdf', '2026-04-22', '見積提示', 'success', 2,
  0, 1, 1
);

-- 8004: 電話・事故対応・顧客1001 事故4001
INSERT INTO t_activity (
  id, customer_id, contract_id, renewal_case_id, sales_case_id, accident_case_id,
  activity_date, start_time, end_time, activity_type, purpose_type,
  visit_place, interviewee_name, subject, content_summary, detail_text,
  next_action_date, next_action_note, result_type, staff_id,
  is_deleted, created_by, updated_by
) VALUES (
  8004, 1001, 2001, NULL, NULL, 4001,
  '2026-04-10', '16:30:00', '16:45:00', 'call', 'accident',
  NULL, '総務部 田中様', '事故受付連絡',
  '駐車場接触事故を受付。SC 手配の旨を伝達。',
  NULL, '2026-04-13', '事故進捗連絡', 'success', 1,
  0, 1, 1
);

-- 8005: メール・クロスセル・顧客1002 見込9002
INSERT INTO t_activity (
  id, customer_id, contract_id, renewal_case_id, sales_case_id, accident_case_id,
  activity_date, start_time, end_time, activity_type, purpose_type,
  visit_place, interviewee_name, subject, content_summary, detail_text,
  next_action_date, next_action_note, result_type, staff_id,
  is_deleted, created_by, updated_by
) VALUES (
  8005, 1002, NULL, NULL, 9002, NULL,
  '2026-04-14', NULL, NULL, 'email', 'cross_sell',
  NULL, 'テスト運輸 経理部様', '動産総合 見積のご送付',
  '動産総合保険の見積書をメール送付。',
  NULL, '2026-04-25', 'フォロー連絡', 'success', 1,
  0, 1, 1
);

-- 8006: 訪問・満期対応・顧客1003 契約2004 満期3004
INSERT INTO t_activity (
  id, customer_id, contract_id, renewal_case_id, sales_case_id, accident_case_id,
  activity_date, start_time, end_time, activity_type, purpose_type,
  visit_place, interviewee_name, subject, content_summary, detail_text,
  next_action_date, next_action_note, result_type, staff_id,
  is_deleted, created_by, updated_by
) VALUES (
  8006, 1003, 2004, 3004, NULL, NULL,
  '2026-04-14', '11:00:00', '11:45:00', 'visit', 'renewal',
  '山田様ご自宅', '山田 太郎 様', '自動車更改 見積説明',
  '見積書を持参し説明。返答待ち。',
  NULL, '2026-04-28', '返答確認', 'success', 2,
  0, 1, 1
);

-- 8007: 電話・フォロー・顧客1004 事故4003
INSERT INTO t_activity (
  id, customer_id, contract_id, renewal_case_id, sales_case_id, accident_case_id,
  activity_date, start_time, end_time, activity_type, purpose_type,
  visit_place, interviewee_name, subject, content_summary, detail_text,
  next_action_date, next_action_note, result_type, staff_id,
  is_deleted, created_by, updated_by
) VALUES (
  8007, 1004, 2005, NULL, NULL, 4003,
  '2026-04-08', '15:00:00', '15:20:00', 'call', 'follow_up',
  NULL, '佐藤 花子 様', '水濡れ事故 進捗連絡',
  '業者手配と保険支払見込みをご案内。',
  NULL, '2026-04-22', '修理完了確認', 'success', 2,
  0, 1, 1
);

-- 8008: 内務・訪問外・スタッフ1
INSERT INTO t_activity (
  id, customer_id, contract_id, renewal_case_id, sales_case_id, accident_case_id,
  activity_date, start_time, end_time, activity_type, purpose_type,
  visit_place, interviewee_name, subject, content_summary, detail_text,
  next_action_date, next_action_note, result_type, staff_id,
  is_deleted, created_by, updated_by
) VALUES (
  8008, NULL, NULL, NULL, NULL, NULL,
  '2026-04-15', '09:00:00', '10:00:00', 'other', 'admin',
  NULL, NULL, '日次 SJ-NET 取込確認',
  'SJ-NET 取込バッチ結果の確認と異常検知レビュー。',
  NULL, NULL, NULL, 'success', 1,
  0, 1, 1
);
