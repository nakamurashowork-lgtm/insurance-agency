-- =====================================================================
-- ダミーデータ: t_accident_case（事故案件）
-- 投入先: 検証環境のみ（本番禁止）
-- 用途  : 動作確認用の事故案件サンプル（受付/対応中/解決を網羅）
-- 件数  : 4件
-- ID範囲: 4001 - 4004
-- 依存  : 02_m_customer.sql, 03_t_contract.sql, 01_m_staff.sql
-- 関連DDL: config/ddl/tenant/t_accident_case.sql
-- =====================================================================

SET NAMES utf8mb4;

-- 4001: 受付・法人1001・自動車
INSERT INTO t_accident_case (
  id, customer_id, contract_id, accident_no, accepted_date, accident_date,
  insurance_category, product_type, accident_type, accident_summary, accident_location,
  has_counterparty, status, priority,
  assigned_staff_id, office_staff_id, sc_staff_name, remark, is_deleted,
  created_by, updated_by
) VALUES (
  4001, 1001, 2001, 'ACC-2026-000001', '2026-04-10', '2026-04-09',
  '自動車', 'タフクル', '物損',
  '駐車場内での接触事故。相手車両のバンパーを損傷。', '東京都千代田区内幸町1-1',
  1, 'accepted', 'normal',
  1, 2, NULL, NULL, 0,
  1, 1
);

-- 4002: 保険会社連絡済み・個人1004・自動車
INSERT INTO t_accident_case (
  id, customer_id, contract_id, accident_no, accepted_date, accident_date,
  insurance_category, product_type, accident_type, accident_summary, accident_location,
  has_counterparty, status, priority,
  assigned_staff_id, office_staff_id, sc_staff_name, remark, is_deleted,
  created_by, updated_by
) VALUES (
  4002, 1004, 2006, 'ACC-2026-000002', '2026-04-05', '2026-04-04',
  '自動車', 'GKクルマの保険・家庭用', '物損・人身',
  '交差点での追突事故。軽傷あり。', '神奈川県横浜市西区みなとみらい1-1',
  1, 'linked', 'high',
  2, 2, 'SC 山本', '保険会社 SC 立会い済み。', 0,
  1, 1
);

-- 4003: 対応中・個人1004・火災
INSERT INTO t_accident_case (
  id, customer_id, contract_id, accident_no, accepted_date, accident_date,
  insurance_category, product_type, accident_type, accident_summary, accident_location,
  has_counterparty, status, priority,
  assigned_staff_id, office_staff_id, sc_staff_name, remark, is_deleted,
  created_by, updated_by
) VALUES (
  4003, 1004, 2005, 'ACC-2026-000003', '2026-03-25', '2026-03-24',
  '火災', 'ホームアシスト', '水濡れ',
  '給湯管破損による階下浸水。', '神奈川県横浜市中区新港1-3',
  1, 'in_progress', 'normal',
  2, 2, 'SC 高橋', NULL, 0,
  1, 1
);

-- 4004: 解決済み・個人1003・自動車
INSERT INTO t_accident_case (
  id, customer_id, contract_id, accident_no, accepted_date, accident_date,
  insurance_category, product_type, accident_type, accident_summary, accident_location,
  has_counterparty, resolved_date, status, priority,
  assigned_staff_id, office_staff_id, sc_staff_name, remark, is_deleted,
  created_by, updated_by
) VALUES (
  4004, 1003, 2004, 'ACC-2026-000004', '2026-02-12', '2026-02-10',
  '自動車', 'おとなの自動車', '物損',
  'コンビニ駐車場での単独事故。自損のみ。', '東京都渋谷区神宮前2-1',
  0, '2026-03-15', 'resolved', 'low',
  2, 2, NULL, '示談完了。', 0,
  1, 1
);
