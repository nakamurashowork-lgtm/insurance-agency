-- =====================================================================
-- ダミーデータ: m_staff（担当者マスタ）
-- 投入先: 検証環境のみ（本番禁止）
-- 用途  : 動作確認用の担当者 2名
-- 件数  : 2件
-- ID範囲: 1, 2
-- 依存  : common DB の users (id=1, 2) が投入済みであること
-- 関連DDL: config/ddl/tenant/m_staff.sql
-- =====================================================================

SET NAMES utf8mb4;

INSERT INTO m_staff
  (id, staff_name, is_sales, is_office, user_id, sjnet_code,
   is_active, sort_order, created_by, updated_by)
VALUES
  (1, '中村 翔',       1, 0, 1, NULL, 1, 10, 1, 1),
  (2, 'テスト担当者',  1, 0, 2, NULL, 1, 20, 1, 1)
ON DUPLICATE KEY UPDATE
  staff_name = VALUES(staff_name);
