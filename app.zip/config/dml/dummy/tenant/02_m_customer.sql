-- =====================================================================
-- ダミーデータ: m_customer（顧客）
-- 投入先: 検証環境のみ（本番禁止）
-- 用途  : 動作確認用の顧客サンプル（法人/個人、active/prospect/closed 混在）
-- 件数  : 6件
-- ID範囲: 1001 - 1006
-- 依存  : なし（最初に投入する）
-- 関連DDL: config/ddl/tenant/m_customer.sql
-- =====================================================================

SET NAMES utf8mb4;

-- 1001: 法人・active（契約あり・活動あり）
INSERT INTO m_customer (
  id, customer_type, customer_name, customer_name_kana,
  phone, email, postal_code, address1, address2,
  status, note, is_deleted, created_by, updated_by
) VALUES (
  1001, 'corporate', '株式会社テストコーポレーション', 'カブシキガイシャテストコーポレーション',
  '03-1111-2222', 'info@test-corp.example.jp', '100-0001',
  '東京都千代田区千代田1-1', 'テストビル5F',
  'active', '重要法人顧客（動作確認用）。複数契約あり。', 0, 1, 1
);

-- 1002: 法人・active（運輸）
INSERT INTO m_customer (
  id, customer_type, customer_name, customer_name_kana,
  phone, email, postal_code, address1, address2,
  status, note, is_deleted, created_by, updated_by
) VALUES (
  1002, 'corporate', 'テスト運輸株式会社', 'テストウンユカブシキガイシャ',
  '06-2222-3333', 'info@test-transport.example.jp', '530-0001',
  '大阪府大阪市北区梅田1-2-3', NULL,
  'active', '運送業・フリート契約。', 0, 1, 1
);

-- 1003: 個人・active（自動車契約のみ）
INSERT INTO m_customer (
  id, customer_type, customer_name, customer_name_kana,
  birth_date, phone, email, postal_code, address1, address2,
  status, note, is_deleted, created_by, updated_by
) VALUES (
  1003, 'individual', '山田 太郎', 'ヤマダ タロウ',
  '1980-05-15', '090-1111-2222', 'yamada@example.jp', '150-0001',
  '東京都渋谷区神宮前1-2', 'ルミエール渋谷301',
  'active', NULL, 0, 1, 1
);

-- 1004: 個人・active（家族名義の火災・自動車）
INSERT INTO m_customer (
  id, customer_type, customer_name, customer_name_kana,
  birth_date, phone, email, postal_code, address1, address2,
  status, note, is_deleted, created_by, updated_by
) VALUES (
  1004, 'individual', '佐藤 花子', 'サトウ ハナコ',
  '1975-11-03', '080-3333-4444', NULL, '231-0001',
  '神奈川県横浜市中区新港1-3', NULL,
  'active', NULL, 0, 1, 1
);

-- 1005: 個人・prospect（見込み顧客、契約なし）
INSERT INTO m_customer (
  id, customer_type, customer_name, customer_name_kana,
  birth_date, phone, email, postal_code, address1, address2,
  status, note, is_deleted, created_by, updated_by
) VALUES (
  1005, 'individual', '鈴木 一郎', 'スズキ イチロウ',
  '1990-03-20', '070-5555-6666', 'suzuki@example.jp', '460-0001',
  '愛知県名古屋市中区錦3-4', NULL,
  'prospect', '紹介案件。自動車保険の見積依頼中。', 0, 1, 1
);

-- 1006: 法人・closed（解約済み）
INSERT INTO m_customer (
  id, customer_type, customer_name, customer_name_kana,
  phone, email, postal_code, address1, address2,
  status, note, is_deleted, created_by, updated_by
) VALUES (
  1006, 'corporate', '旧テスト商店', 'キュウテストショウテン',
  '011-7777-8888', NULL, '060-0001',
  '北海道札幌市中央区北1条西1', NULL,
  'closed', '2025年3月末で廃業のため全契約終了。', 0, 1, 1
);
