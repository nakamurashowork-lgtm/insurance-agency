-- =====================================================================
-- ダミーデータ: t_contract（契約）
-- 投入先: 検証環境のみ（本番禁止）
-- 用途  : 動作確認用の契約サンプル（自動車/火災/傷害、満期日の分散あり）
-- 件数  : 8件
-- ID範囲: 2001 - 2008
-- 依存  : 02_m_customer.sql, 01_m_staff.sql
-- 関連DDL: config/ddl/tenant/t_contract.sql
-- =====================================================================

SET NAMES utf8mb4;

-- 2001: 法人1001・自動車・active（近い満期日）
INSERT INTO t_contract (
  id, customer_id, insured_customer_id, policy_no, insurance_category, product_type,
  policy_start_date, policy_end_date, premium_amount, payment_cycle, status,
  sales_staff_id, office_staff_id, remark, is_deleted, created_by, updated_by
) VALUES (
  2001, 1001, 1001, 'POL-2024-000001', '自動車', 'タフクル',
  '2025-05-01', '2026-05-01', 280000, 'annual', 'active',
  1, 2, 'フリート契約。', 0, 1, 1
);

-- 2002: 法人1001・火災・active
INSERT INTO t_contract (
  id, customer_id, insured_customer_id, policy_no, insurance_category, product_type,
  policy_start_date, policy_end_date, premium_amount, payment_cycle, status,
  sales_staff_id, office_staff_id, remark, is_deleted, created_by, updated_by
) VALUES (
  2002, 1001, 1001, 'POL-2024-000002', '火災', 'すまいの保険',
  '2024-10-01', '2026-10-01', 55000, 'annual', 'active',
  1, 2, NULL, 0, 1, 1
);

-- 2003: 法人1002・自動車（運輸フリート）・active
INSERT INTO t_contract (
  id, customer_id, insured_customer_id, policy_no, insurance_category, product_type,
  policy_start_date, policy_end_date, premium_amount, payment_cycle, status,
  sales_staff_id, office_staff_id, remark, is_deleted, created_by, updated_by
) VALUES (
  2003, 1002, 1002, 'POL-2024-000003', '自動車', '事業用Ｋ・Ａ・Ｐ',
  '2025-07-01', '2026-07-01', 1200000, 'annual', 'active',
  1, 2, '運輸フリート契約。', 0, 1, 1
);

-- 2004: 個人1003・自動車・active（満期まで2か月以内）
INSERT INTO t_contract (
  id, customer_id, insured_customer_id, policy_no, insurance_category, product_type,
  policy_start_date, policy_end_date, premium_amount, payment_cycle, status,
  sales_staff_id, office_staff_id, remark, is_deleted, created_by, updated_by
) VALUES (
  2004, 1003, 1003, 'POL-2024-000004', '自動車', 'おとなの自動車',
  '2025-06-01', '2026-06-01', 75000, 'annual', 'active',
  2, 2, NULL, 0, 1, 1
);

-- 2005: 個人1004・火災・active
INSERT INTO t_contract (
  id, customer_id, insured_customer_id, policy_no, insurance_category, product_type,
  policy_start_date, policy_end_date, premium_amount, payment_cycle, status,
  sales_staff_id, office_staff_id, remark, is_deleted, created_by, updated_by
) VALUES (
  2005, 1004, 1004, 'POL-2024-000005', '火災', 'ホームアシスト',
  '2025-09-01', '2026-09-01', 42000, 'annual', 'active',
  2, 2, NULL, 0, 1, 1
);

-- 2006: 個人1004・自動車・active
INSERT INTO t_contract (
  id, customer_id, insured_customer_id, policy_no, insurance_category, product_type,
  policy_start_date, policy_end_date, premium_amount, payment_cycle, status,
  sales_staff_id, office_staff_id, remark, is_deleted, created_by, updated_by
) VALUES (
  2006, 1004, 1004, 'POL-2024-000006', '自動車', 'GKクルマの保険・家庭用',
  '2025-04-01', '2026-04-01', 92000, 'annual', 'active',
  2, 2, NULL, 0, 1, 1
);

-- 2007: 法人1006・自動車・cancelled（解約済み）
INSERT INTO t_contract (
  id, customer_id, insured_customer_id, policy_no, insurance_category, product_type,
  policy_start_date, policy_end_date, premium_amount, payment_cycle, status,
  sales_staff_id, office_staff_id, remark, is_deleted, created_by, updated_by
) VALUES (
  2007, 1006, 1006, 'POL-2023-000007', '自動車', 'タフクル',
  '2024-04-01', '2025-04-01', 180000, 'annual', 'cancelled',
  1, 2, '廃業により中途解約。', 0, 1, 1
);

-- 2008: 個人1003・傷害・active
INSERT INTO t_contract (
  id, customer_id, insured_customer_id, policy_no, insurance_category, product_type,
  policy_start_date, policy_end_date, premium_amount, payment_cycle, status,
  sales_staff_id, office_staff_id, remark, is_deleted, created_by, updated_by
) VALUES (
  2008, 1003, 1003, 'POL-2024-000008', '傷害', '普通傷害',
  '2025-08-01', '2026-08-01', 18000, 'annual', 'active',
  2, 2, NULL, 0, 1, 1
);
