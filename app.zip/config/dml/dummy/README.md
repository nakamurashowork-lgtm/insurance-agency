# config/dml/dummy/ — ダミーデータ（業務サンプル）

## 概要

業務を模した動作確認用のサンプルデータ。
**検証環境のみ**に投入する。**本番環境には絶対に投入しないこと。**

画面動作・検索・詳細・更新・通知などを一通り検証できる最小セットで構成されている。

---

## フォルダ構成

```
config/dml/dummy/
├── README.md                        ← 本ファイル
├── common/                          ← common DB（xs000001_admin 等）
│   ├── 01_users.sql
│   └── 02_user_tenants.sql
└── tenant/                          ← テナント DB（xs000001_teXXX 等）
    ├── 00_cleanup.sql
    ├── 01_m_staff.sql
    ├── 02_m_customer.sql
    ├── 03_t_contract.sql
    ├── 04_t_renewal_case.sql
    ├── 05_t_accident_case.sql
    ├── 06_t_sales_case.sql
    └── 07_t_activity.sql
```

---

## 投入前提

1. 対象 DB に DDL が適用済みであること
2. `config/dml/master/` のマスターデータ（対応状況・種目・社内顧客）が投入済みであること
3. `common.tenants` に `TE001` レコードが存在すること（テナント作成は手動運用）

---

## ファイル一覧と投入順序

### common DB（xs000001_admin 等）

| 順序 | ファイル | テーブル | 件数 | ID範囲 |
|---|---|---|---|---|
| 1 | `common/01_users.sql` | `users` | 3 | 1, 2, 99 |
| 2 | `common/02_user_tenants.sql` | `user_tenants` | 3 | — |

### テナント DB（xs000001_te001 等）

| 順序 | ファイル | テーブル | 件数 | ID範囲 |
|---|---|---|---|---|
| 0 | `tenant/00_cleanup.sql` | （全テーブル） | — | 再投入時に先に実行 |
| 1 | `tenant/01_m_staff.sql` | `m_staff` | 2 | 1, 2 |
| 2 | `tenant/02_m_customer.sql` | `m_customer` | 6 | 1001 – 1006 |
| 3 | `tenant/03_t_contract.sql` | `t_contract` | 8 | 2001 – 2008 |
| 4 | `tenant/04_t_renewal_case.sql` | `t_renewal_case` | 8 | 3001 – 3008 |
| 5 | `tenant/05_t_accident_case.sql` | `t_accident_case` | 4 | 4001 – 4004 |
| 6 | `tenant/06_t_sales_case.sql` | `t_sales_case` | 4 | 9001 – 9004 |
| 7 | `tenant/07_t_activity.sql` | `t_activity` | 8 | 8001 – 8008 |

---

## 投入手順

### phpMyAdmin

1. common DB（例: `xs000001_admin`）を選択して `common/01_users.sql`, `02_user_tenants.sql` を順に実行
2. テナント DB（例: `xs000001_te001`）を選択して `tenant/00_cleanup.sql` 以降を順に実行

### コマンドライン（MySQL CLI）

```bash
# common DB
mysql --default-character-set=utf8mb4 -u root xs000001_admin < config/dml/dummy/common/01_users.sql
mysql --default-character-set=utf8mb4 -u root xs000001_admin < config/dml/dummy/common/02_user_tenants.sql

# tenant DB
mysql --default-character-set=utf8mb4 -u root xs000001_te001 < config/dml/dummy/tenant/00_cleanup.sql
mysql --default-character-set=utf8mb4 -u root xs000001_te001 < config/dml/dummy/tenant/01_m_staff.sql
mysql --default-character-set=utf8mb4 -u root xs000001_te001 < config/dml/dummy/tenant/02_m_customer.sql
mysql --default-character-set=utf8mb4 -u root xs000001_te001 < config/dml/dummy/tenant/03_t_contract.sql
mysql --default-character-set=utf8mb4 -u root xs000001_te001 < config/dml/dummy/tenant/04_t_renewal_case.sql
mysql --default-character-set=utf8mb4 -u root xs000001_te001 < config/dml/dummy/tenant/05_t_accident_case.sql
mysql --default-character-set=utf8mb4 -u root xs000001_te001 < config/dml/dummy/tenant/06_t_sales_case.sql
mysql --default-character-set=utf8mb4 -u root xs000001_te001 < config/dml/dummy/tenant/07_t_activity.sql
```

---

## 再投入（クリーンアップ → 再適用）

```
1. tenant/00_cleanup.sql を実行（ID範囲指定でダミーデータのみ削除）
2. tenant/01 ～ 07 を順に実行
```

`00_cleanup.sql` は **ID 範囲指定** の DELETE のため、master のマスターデータや手動で追加した別 ID のレコードには影響しない。

---

## サンプルの業務シナリオ

### 顧客（6件）

| ID | 種別 | ステータス | 内容 |
|---|---|---|---|
| 1001 | 法人 | active | 重要顧客（複数契約・事故あり） |
| 1002 | 法人 | active | 運輸フリート |
| 1003 | 個人 | active | 自動車・傷害契約 |
| 1004 | 個人 | active | 自動車・火災 |
| 1005 | 個人 | prospect | 見込案件中（契約なし） |
| 1006 | 法人 | closed | 廃業のため解約済み |

### 満期案件（8件、全 case_status を網羅）

| ID | case_status | 契約 | 備考 |
|---|---|---|---|
| 3001 | not_started | 2001 | 未対応 |
| 3002 | sj_requested | 2002 | SJ依頼中 |
| 3003 | doc_prepared | 2003 | 書類作成済 |
| 3004 | quote_sent | 2004 | 見積送付済 |
| 3005 | waiting_return | 2005 | 返送待ち |
| 3006 | waiting_payment | 2006 | 入金待ち |
| 3007 | completed (renewed) | 2008 | 更改済み |
| 3008 | completed (lost) | 2007 | 失注（廃業） |

### 事故案件（4件）

| ID | status | 顧客 | 契約 |
|---|---|---|---|
| 4001 | accepted | 1001 | 2001 |
| 4002 | linked | 1004 | 2006 |
| 4003 | in_progress | 1004 | 2005 |
| 4004 | resolved | 1003 | 2004 |

### 見込案件（4件、全 status を網羅）

| ID | status | 顧客 | 備考 |
|---|---|---|---|
| 9001 | open | 1005 | 商談中 |
| 9002 | negotiating | 1002 | 交渉中・クロスセル |
| 9003 | won | 1003 | 契約 2008 として成約 |
| 9004 | lost | (prospect_name のみ) | 失注 |

### 活動履歴（8件、活動種別 × 用件区分の組み合わせ）

- 訪問（visit）× 満期・新規・満期
- 電話（call）× 満期・事故・フォロー
- メール（email）× クロスセル
- その他（other）× 内務

---

## 本番環境への誤投入防止

- 全ファイルに `投入先: 検証環境のみ（本番禁止）` コメントを明記
- ID が 1000 番台以降（1001–1006, 2001–2008, 3001–3008, 4001–4004, 8001–8008, 9001–9004）で固定。本番で衝突する可能性が低い一方、**本番投入は絶対禁止**
- 本番環境に誤投入した場合の復旧は `00_cleanup.sql` で削除可能だが、関連する監査ログ・通知履歴まではクリーンアップされないため、注意深く運用すること

---

## 既存データへの影響範囲

| テーブル | 影響範囲 |
|---|---|
| `users` | id 1, 2, 99 のみ（INSERT IGNORE） |
| `user_tenants` | (user_id, tenant_code) 重複はスキップ（INSERT IGNORE） |
| `m_staff` | id 1, 2 のみ（ON DUPLICATE KEY UPDATE） |
| `m_customer` | id 1001–1006 のみ |
| `t_contract` | id 2001–2008 のみ |
| `t_renewal_case` | id 3001–3008 のみ |
| `t_accident_case` | id 4001–4004 のみ |
| `t_sales_case` | id 9001–9004 のみ |
| `t_activity` | id 8001–8008 のみ |
