<?php
declare(strict_types=1);

namespace App\Domain\Renewal;

use PDO;

final class ContractRepository
{
    public function __construct(private PDO $pdo)
    {
    }

    /**
     * 顧客紐づけ操作（設定・変更・解除）
     *
     * t_contract.customer_id を更新し、監査ログを記録する。
     *
     * @param int   $contractId  対象契約ID
     * @param int|null $newCustomerId  紐づける顧客ID。NULL は紐づけ解除
     * @param int   $userId      操作者ID (common.users.id)
     */
    public function linkCustomer(int $contractId, ?int $newCustomerId, int $userId): void
    {
        // 変更前の customer_id を取得
        $stmt = $this->pdo->prepare(
            'SELECT customer_id FROM t_contract WHERE id = :id AND is_deleted = 0 LIMIT 1'
        );
        $stmt->bindValue(':id', $contractId, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!is_array($row)) {
            throw new \RuntimeException('契約が見つかりません: contract_id=' . $contractId);
        }

        $beforeCustomerId = $row['customer_id'] !== null ? (int) $row['customer_id'] : null;

        // 変化がなければ何もしない
        if ($beforeCustomerId === $newCustomerId) {
            return;
        }

        // t_contract.customer_id を更新
        $stmt = $this->pdo->prepare(
            'UPDATE t_contract
             SET customer_id = :customer_id,
                 updated_by  = :updated_by
             WHERE id = :id
               AND is_deleted = 0'
        );
        $stmt->bindValue(':customer_id', $newCustomerId, $newCustomerId !== null ? PDO::PARAM_INT : PDO::PARAM_NULL);
        $stmt->bindValue(':updated_by', $userId, PDO::PARAM_INT);
        $stmt->bindValue(':id', $contractId, PDO::PARAM_INT);
        $stmt->execute();

        // 監査ログを記録
        $now = date('Y-m-d H:i:s');
        $stmt = $this->pdo->prepare(
            'INSERT INTO t_audit_event
               (entity_type, entity_id, action_type, change_source, changed_by, changed_at, note)
             VALUES
               (\'contract\', :entity_id, \'UPDATE\', \'SCREEN\', :changed_by, :changed_at, :note)'
        );
        $note = $newCustomerId !== null
            ? '顧客紐づけ変更 (customer_id: ' . ($beforeCustomerId ?? 'NULL') . ' → ' . $newCustomerId . ')'
            : '顧客紐づけ解除 (customer_id: ' . ($beforeCustomerId ?? 'NULL') . ' → NULL)';
        $stmt->bindValue(':entity_id', $contractId, PDO::PARAM_INT);
        $stmt->bindValue(':changed_by', $userId, PDO::PARAM_INT);
        $stmt->bindValue(':changed_at', $now);
        $stmt->bindValue(':note', $note);
        $stmt->execute();

        $auditEventId = (int) $this->pdo->lastInsertId();

        // 監査詳細を記録
        $stmt = $this->pdo->prepare(
            'INSERT INTO t_audit_event_detail
               (audit_event_id, field_key, field_label, value_type, before_value_text, after_value_text)
             VALUES
               (:event_id, \'customer_id\', \'顧客\', \'NUMBER\', :before, :after)'
        );
        $stmt->bindValue(':event_id', $auditEventId, PDO::PARAM_INT);
        $stmt->bindValue(':before', $beforeCustomerId !== null ? (string) $beforeCustomerId : null);
        $stmt->bindValue(':after', $newCustomerId !== null ? (string) $newCustomerId : null);
        $stmt->execute();
    }

    /**
     * 契約に紐づく contract_id を返す（テナント境界チェック用）
     */
    public function findById(int $contractId): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT id, customer_id, policy_no FROM t_contract WHERE id = :id AND is_deleted = 0 LIMIT 1'
        );
        $stmt->bindValue(':id', $contractId, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return is_array($row) ? $row : null;
    }
}
