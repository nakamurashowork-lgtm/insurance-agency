<?php
declare(strict_types=1);

namespace App\Domain\Tenant;

use PDO;

/**
 * 見込案件ステータスマスタ（m_sales_case_status）
 *
 * システムコード（open/negotiating/won/lost/on_hold）はアプリロジック
 * （バッジ色・失注理由表示条件・ダッシュボード集計）に依存するため変更不可。
 * 画面からは表示名・表示順・有効無効の切替が可能で、
 * さらにカスタムステータスの追加・削除もサポートする。
 */
final class SalesCaseStatusRepository
{
    /** システムコード（コード変更・削除不可） */
    public const SYSTEM_CODES = ['open', 'negotiating', 'won', 'lost', 'on_hold'];

    public function __construct(private PDO $pdo)
    {
    }

    /**
     * カスタムステータスを新規追加する。コードは custom_001, custom_002... と自動採番する。
     */
    public function create(string $displayName): int
    {
        $stmt = $this->pdo->query('SELECT COALESCE(MAX(display_order), 0) FROM m_sales_case_status');
        $maxOrder = (int) $stmt->fetchColumn();

        $code = $this->generateCustomCode();

        $stmt = $this->pdo->prepare(
            'INSERT INTO m_sales_case_status (code, display_name, display_order, is_active)
             VALUES (:code, :display_name, :display_order, 1)'
        );
        $stmt->bindValue(':code', $code);
        $stmt->bindValue(':display_name', $displayName);
        $stmt->bindValue(':display_order', $maxOrder + 1, PDO::PARAM_INT);
        $stmt->execute();
        return (int) $this->pdo->lastInsertId();
    }

    /**
     * カスタムコードを生成する（custom_001, custom_002, ...）。
     * システムコードと衝突しないよう custom_ プレフィックスを固定で使う。
     */
    private function generateCustomCode(): string
    {
        $stmt = $this->pdo->query(
            "SELECT code FROM m_sales_case_status
             WHERE code REGEXP '^custom_[0-9]+$'
             ORDER BY CAST(SUBSTRING(code, 8) AS UNSIGNED) DESC LIMIT 1"
        );
        $lastCode = (string) ($stmt->fetchColumn() ?: '');
        $num = 0;
        if (preg_match('/^custom_(\d+)$/', $lastCode, $m)) {
            $num = (int) $m[1];
        }
        return sprintf('custom_%03d', $num + 1);
    }

    /**
     * カスタムステータス（システムコード以外）を物理削除する。
     *
     * @throws \DomainException
     */
    public function delete(int $id): void
    {
        $row = $this->findById($id);
        if ($row === null) {
            throw new \DomainException('対象が見つかりません。');
        }
        $code = (string) ($row['code'] ?? '');
        if (in_array($code, self::SYSTEM_CODES, true)) {
            throw new \DomainException('システムコードは削除できません。');
        }
        $stmt = $this->pdo->prepare('DELETE FROM m_sales_case_status WHERE id = :id');
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
    }

    /**
     * 指定コードがシステムコードかどうか。
     */
    public static function isSystemCode(string $code): bool
    {
        return in_array($code, self::SYSTEM_CODES, true);
    }

    /**
     * 全件取得（管理画面・検索フォーム用）
     *
     * @return array<int, array<string, mixed>>
     */
    public function findAll(): array
    {
        $rows = $this->pdo->query(
            'SELECT id, code, display_name, display_order, is_active, created_at, updated_at
             FROM m_sales_case_status
             ORDER BY is_active DESC, display_order ASC, id ASC'
        )->fetchAll(PDO::FETCH_ASSOC);
        return is_array($rows) ? $rows : [];
    }

    /**
     * 有効なものだけ（編集フォームのプルダウン用）
     *
     * @return array<int, array<string, mixed>>
     */
    public function findActive(): array
    {
        $rows = $this->pdo->query(
            'SELECT id, code, display_name, display_order
             FROM m_sales_case_status
             WHERE is_active = 1
             ORDER BY display_order ASC, id ASC'
        )->fetchAll(PDO::FETCH_ASSOC);
        return is_array($rows) ? $rows : [];
    }

    /**
     * code → display_name の連想配列（既存レコードのラベル解決用）
     *
     * @return array<string, string>
     */
    public function codeNameMap(): array
    {
        $rows = $this->pdo->query(
            'SELECT code, display_name FROM m_sales_case_status'
        )->fetchAll(PDO::FETCH_ASSOC);
        $map = [];
        foreach ((array) $rows as $row) {
            $map[(string) ($row['code'] ?? '')] = (string) ($row['display_name'] ?? '');
        }
        return $map;
    }

    /**
     * バリデーション用：有効なコード一覧
     *
     * @return list<string>
     */
    public function findActiveCodes(): array
    {
        $rows = $this->findActive();
        return array_values(array_map(
            static fn(array $r) => (string) ($r['code'] ?? ''),
            $rows
        ));
    }

    /** @return array<string, mixed>|null */
    public function findById(int $id): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT id, code, display_name, display_order, is_active
             FROM m_sales_case_status WHERE id = :id LIMIT 1'
        );
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return is_array($row) ? $row : null;
    }

    public function updateDisplayName(int $id, string $displayName): int
    {
        $stmt = $this->pdo->prepare(
            'UPDATE m_sales_case_status SET display_name = :display_name WHERE id = :id'
        );
        $stmt->bindValue(':display_name', $displayName);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->rowCount();
    }

    public function setActive(int $id, int $active): int
    {
        $stmt = $this->pdo->prepare(
            'UPDATE m_sales_case_status SET is_active = :active WHERE id = :id'
        );
        $stmt->bindValue(':active', $active, PDO::PARAM_INT);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->rowCount();
    }

    /**
     * 表示順を隣接行と入れ替える
     * @return bool 交換が実行された場合 true
     */
    public function swapDisplayOrder(int $id, string $direction): bool
    {
        $self = $this->findById($id);
        if ($self === null) {
            return false;
        }
        $selfOrder = (int) ($self['display_order'] ?? 0);

        if ($direction === 'up') {
            $stmt = $this->pdo->prepare(
                'SELECT id, display_order FROM m_sales_case_status
                 WHERE display_order < :order ORDER BY display_order DESC LIMIT 1'
            );
        } else {
            $stmt = $this->pdo->prepare(
                'SELECT id, display_order FROM m_sales_case_status
                 WHERE display_order > :order ORDER BY display_order ASC LIMIT 1'
            );
        }
        $stmt->bindValue(':order', $selfOrder, PDO::PARAM_INT);
        $stmt->execute();
        $neighbor = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($neighbor)) {
            return false;
        }

        $neighborId    = (int) ($neighbor['id'] ?? 0);
        $neighborOrder = (int) ($neighbor['display_order'] ?? 0);

        $upd = $this->pdo->prepare(
            'UPDATE m_sales_case_status SET display_order = :order WHERE id = :id'
        );
        $upd->bindValue(':order', $neighborOrder, PDO::PARAM_INT);
        $upd->bindValue(':id', $id, PDO::PARAM_INT);
        $upd->execute();

        $upd->bindValue(':order', $selfOrder, PDO::PARAM_INT);
        $upd->bindValue(':id', $neighborId, PDO::PARAM_INT);
        $upd->execute();

        return true;
    }
}
