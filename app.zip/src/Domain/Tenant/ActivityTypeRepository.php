<?php
declare(strict_types=1);

namespace App\Domain\Tenant;

use PDO;

final class ActivityTypeRepository
{
    public function __construct(private PDO $pdo)
    {
    }

    /** @return array<int, array<string, mixed>> */
    public function findAll(): array
    {
        $rows = $this->pdo->query(
            'SELECT code, label, display_order, is_active, created_at, updated_at
             FROM m_activity_type
             ORDER BY is_active DESC, display_order ASC, code ASC'
        )->fetchAll();
        return is_array($rows) ? $rows : [];
    }

    /** @return array<int, array<string, mixed>>  有効なものだけ（プルダウン用） */
    public function findActive(): array
    {
        $rows = $this->pdo->query(
            'SELECT code, label, display_order
             FROM m_activity_type
             WHERE is_active = 1
             ORDER BY display_order ASC, code ASC'
        )->fetchAll(PDO::FETCH_ASSOC);
        return is_array($rows) ? $rows : [];
    }

    /** @return array<string, string>  code => label マップ（バリデーション・View 用） */
    public function findActiveMap(): array
    {
        $map = [];
        foreach ($this->findActive() as $row) {
            $map[(string) $row['code']] = (string) $row['label'];
        }
        return $map;
    }

    /** @return array<string, mixed>|null */
    public function findByCode(string $code): ?array
    {
        $stmt = $this->pdo->prepare(
            'SELECT code, label, display_order, is_active FROM m_activity_type WHERE code = :code LIMIT 1'
        );
        $stmt->bindValue(':code', $code);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return is_array($row) ? $row : null;
    }

    /** コードは呼び出し元で自動生成する */
    public function create(string $code, string $label): void
    {
        $maxOrder = (int) $this->pdo->query(
            'SELECT COALESCE(MAX(display_order), 0) FROM m_activity_type'
        )->fetchColumn();

        $stmt = $this->pdo->prepare(
            'INSERT INTO m_activity_type (code, label, display_order, is_active)
             VALUES (:code, :label, :display_order, 1)'
        );
        $stmt->bindValue(':code', $code);
        $stmt->bindValue(':label', $label);
        $stmt->bindValue(':display_order', $maxOrder + 1, PDO::PARAM_INT);
        $stmt->execute();
    }

    public function update(string $code, string $label): int
    {
        $stmt = $this->pdo->prepare(
            'UPDATE m_activity_type SET label = :label WHERE code = :code'
        );
        $stmt->bindValue(':label', $label);
        $stmt->bindValue(':code', $code);
        $stmt->execute();
        return $stmt->rowCount();
    }

    public function setActive(string $code, int $active): int
    {
        $stmt = $this->pdo->prepare(
            'UPDATE m_activity_type SET is_active = :active WHERE code = :code'
        );
        $stmt->bindValue(':active', $active, PDO::PARAM_INT);
        $stmt->bindValue(':code', $code);
        $stmt->execute();
        return $stmt->rowCount();
    }

    public function delete(string $code): void
    {
        $stmt = $this->pdo->prepare('DELETE FROM m_activity_type WHERE code = :code');
        $stmt->bindValue(':code', $code);
        $stmt->execute();
    }

    public function swapDisplayOrder(string $code, string $direction): bool
    {
        $self = $this->findByCode($code);
        if ($self === null) {
            return false;
        }
        $selfOrder = (int) ($self['display_order'] ?? 0);

        if ($direction === 'up') {
            $stmt = $this->pdo->prepare(
                'SELECT code, display_order FROM m_activity_type
                 WHERE display_order < :order ORDER BY display_order DESC LIMIT 1'
            );
        } else {
            $stmt = $this->pdo->prepare(
                'SELECT code, display_order FROM m_activity_type
                 WHERE display_order > :order ORDER BY display_order ASC LIMIT 1'
            );
        }
        $stmt->bindValue(':order', $selfOrder, PDO::PARAM_INT);
        $stmt->execute();
        $neighbor = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($neighbor)) {
            return false;
        }

        $neighborCode  = (string) ($neighbor['code'] ?? '');
        $neighborOrder = (int) ($neighbor['display_order'] ?? 0);

        $upd = $this->pdo->prepare(
            'UPDATE m_activity_type SET display_order = :order WHERE code = :code'
        );
        $upd->bindValue(':order', $neighborOrder, PDO::PARAM_INT);
        $upd->bindValue(':code', $code);
        $upd->execute();

        $upd->bindValue(':order', $selfOrder, PDO::PARAM_INT);
        $upd->bindValue(':code', $neighborCode);
        $upd->execute();

        return true;
    }
}
